
// PRODUCTION

var hsconfig = {

  // Design and Layout
  appDesign: {
    webPageTitle: "Marion, IL Code Enforcement & Inspector Tools", // Title displayed in browser tab/bookmarks
    applicationTitle: "City of Marion, IL", // Title displayed on the application/page
    applicationSubtitle: "Code Enforcement and Inspector Tools", // Subtitle displayed on the application/page
    logo: "images/marionil40.png", // Logo displayed in upper-left corner of application
    logoTitle: "City of Marion, IL" // Title displayed on hover logo
  },
  
  // Map Settings
  mapSettings: {
   coords: [-88.958406, 37.740694], // X Coords, Y Coords
   zoom: 16, // Zoom level x-x
   basemap: "satellite" // Options: "satellite", "streets"
  },
  
  // Map Capabilities
  mapCapabilities: {
    mapEditable: true
  },
  
  printService: {
    url: "http://maps.hornershifrin.com/arcgis/rest/services/BirchTree/ExportWebMap/GPServer/Export%20Web%20Map"
  },
  
  // Time Slider
  timeSlider: {
    timeLayer: "InspectionHistory",
    timeSliderLabel: "Inspection History",
    timeSliderDefinitionQueryField: "Status"
  },
  
  // Map Layers
  layersConfig: [
    {
      reference: "CommentFlags",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/Marion_InspectorTools_FeatureLayer/FeatureServer/5",
      mode: "MODE_ONDEMAND",
      hasAttachments: true,
      isEditable: true,
      visible: false,
      popup: true,
      excludeFromLayerList: false,
      outFields: ["*"],
      hideFields: ["OBJECTID", "GlobalID", "Resolved"]
    },
    {
      reference: "Complaints",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/MarionILCodeEnforcement/FeatureServer/7",
      mode: "MODE_ONDEMAND",
      hasAttachments: true,
      isEditable: true,
      visible: true,
      popup: true,
      excludeFromLayerList: false,
      outFields: ["*"],
      hideFields: ["OBJECTID", "GlobalID", "Resolved", "RELSTRUCTID"]
    },
    {
      reference: "InspectionHistory",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/Marion_InspectorTools_FeatureLayer/FeatureServer/6",
      mode: "MODE_SNAPSHOT",
      hasAttachments: true,
      isEditable: true,
      visible: false,
      popup: true,
      excludeFromLayerList: false,
      outFields: ["*"],
      hideFields: ["OBJECTID", "GlobalID"]
    },
    {
      reference: "CodeViolationsDue",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/Marion_InspectorTools_FeatureLayer/FeatureServer/1",
      mode: "MODE_ONDEMAND",
      hasAttachments: true,
      isEditable: true,
      //editGeometry: true,
      visible: true,
      popup: false,
      task: true,
      outFields: ["*"],
      hideFields: ["OBJECTID", "GlobalID"]
      //queryFeatures: {
        //fields: ["RCSD_No", "Survey_No", "InspectedBy"]
      //}
    },
    {
      reference: "CodeViolationsPending",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/Marion_InspectorTools_FeatureLayer/FeatureServer/2",
      mode: "MODE_ONDEMAND",
      hasAttachments: true,
      isEditable: true,
      visible: true,
      popup: false,
      task: true,
      outFields: ["*"],
      hideFields: ["OBJECTID", "GlobalID"]
      //queryFeatures: {
        //fields: ["*"]
      //}
    },
    {
      reference: "RentalInspections",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/Marion_InspectorTools_FeatureLayer/FeatureServer/3",
      mode: "MODE_ONDEMAND",
      hasAttachments: true,
      isEditable: true,
      visible: false,
      popup: false,
      task: true,
      outFields: ["*"],
      hideFields: ["OBJECTID", "GlobalID"]
    },
    {
      reference: "Structures",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/Marion_InspectorTools_QueryLayer/MapServer/1",
      mode: "MODE_ONDEMAND",
      hasAttachments: true,
      isEditable: false,
      visible: true,
      popup: true,
      outFields: ["*"],
      hideFields: ["MarionIL.SDE.Structures.OBJECTID", "MarionIL.SDE.Structures.GlobalID"],
      maxScale: 0,
      minScale: 10000
    },
    {
      reference: "Parcels",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/Marion_InspectorTools_FeatureLayer/FeatureServer/4",
      mode: "MODE_ONDEMAND",
      hasAttachments: true,
      isEditable: false,
      visible: false,
      popup: true,
      outFields: ["*"],
      hideFields: ["OBJECTID", "GlobalID"]
    },
    {
      reference: "Zoning",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/MarionILAdministrative/FeatureServer/6",
      mode: "MODE_ONDEMAND",
      hasAttachments: false,
      isEditable: false,
      visible: false,
      popup: true,
      outFields: ["*"],
      //opacity: .5,
      hideFields: ["OBJECTID", "GlobalID"]
    },
    {
      reference: "FEMAFloodZones",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/MarionILCodeEnforcement/FeatureServer/6",
      mode: "MODE_ONDEMAND",
      hasAttachments: false,
      isEditable: false,
      visible: false,
      popup: true,
      outFields: ["*"],
      //opacity: .5,
      hideFields: ["OBJECTID", "GlobalID"]
    },
    {
      reference: "code_violations",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/Marion_InspectorTools_FeatureLayer/FeatureServer/7",
      mode: "MODE_ONDEMAND",
      hasAttachments: true,
      isEditable: false,
      visible: false,
      excludeFromLayerList: true,
      popup: false,
      outFields: ["*"]
    },
    {
      reference: "structure_owners",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/Marion_InspectorTools_QueryLayer/MapServer/1",
      mode: "MODE_ONDEMAND",
      hasAttachments: true,
      isEditable: false,
      visible: false,
      popup: false,
      //task: "newServiceRequest",
      excludeFromLayerList: true,
      outFields: ["*"]
      },
      {
      reference: "work_order_locations",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/Marion_InspectorTools_QueryLayer/MapServer/0",
      mode: "MODE_ONDEMAND",
      hasAttachments: true,
      isEditable: false,
      visible: false,
      popup: false,
      //task: "newServiceRequest",
      excludeFromLayerList: true,
      outFields: ["*"]
      },
      {
      reference: "rental_inspections",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/Marion_InspectorTools_FeatureLayer/FeatureServer/8",
      mode: "MODE_ONDEMAND",
      hasAttachments: true,
      isEditable: true,
      visible: false,
      popup: false,
      excludeFromLayerList: true,
      outFields: ["*"]
      },
      {
      reference: "comment_flags",
      url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/Marion_InspectorTools_FeatureLayer/FeatureServer/9",
      mode: "MODE_ONDEMAND",
      hasAttachments: true,
      isEditable: true,
      visible: false,
      popup: false,
      excludeFromLayerList: true,
      outFields: ["*"]
      },

  ],
  
  dynamicLayers: [
      {
        reference: "StructureLabels",
        url: "http://maps.hornershifrin.com/arcgis/rest/services/MarionIL/MarionILStructures/MapServer",
        visible: true,
        outFields: ["*"],
        hideFields: ["OBJECTID", "GlobalID"],
        excludeFromLayerList: false,
        dynamicMapServiceLayer: { // Otherwise, assumed feature layer
          visibleLayers: [0],
          options: {
            id: "StructureLabels"
          }
        }
      },
  ],
  
  // Configure tasks/modules
  tasks: {
    "newServiceRequest": {
      name: "newServiceRequest",
      type: "newServiceRequest",
      layer: "ServiceRequestForm"
    }
  },

  panels: [
    // General Application Panels
    {
      id: "Attributes"
    },
    {
      id: "layers",
      button: true
    },
    {
      id: "settings",
      button: true
    },
    {
      id: "help",
      button: true
    },
    // Widget Panels
    {
      id: "draw",
      button: true
    },
    {
      id: "print",
      button: true
    },
    {
      id: "QueryResultList"
    },
    // Special Task Panels
    {
      id: "ServiceRequestList"
    },
    {
      id: "newServiceRequest",
      button: true
    },
    {
      id: "WorkOrderList",
      button: true
    },
    {
      id: "newInspections"
    },
    {
      id: "newViolations"
    },
    {
      id: "editViolations"
    },
    {
      id: "complaints",
      button: true
    }
  ]
};
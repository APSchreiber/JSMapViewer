﻿define([

  // dojo
  "dojo/_base/declare",
  
  // esri
  
  // custom
  
  ], function (
      declare
  ) {
   
  return declare(null, {
    constructor: function(manager) {
     
      // reference to self
      var mapClickManager = this;
      
      /********** initialize **********/
      
      console.log(manager);
      
      // create a click highlight layer
      var clickedGraphicsLayer = "click_graphics_layer";
      manager.layersWidget.addGraphicsLayer(clickedGraphicsLayer);

      /********** methods **********/
      
      this.init = function() {
        manager.map.on("click", function(evt) {
          // graphic click
          if (evt.graphic) {
            var clickedGraphic = evt.graphic;
            // highlight the clicked graphic
            manager.utils.graphicsUtils.highlightGraphic(clickedGraphic, manager.layersWidget.graphicsLayers[clickedGraphicsLayer]);
          }
        });
      }
      
      /********** internal functions **********/
      
      
      
    }
  });
});





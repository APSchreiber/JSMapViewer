﻿define([

  // dojo
  "dojo/_base/declare",
  
  // esri
  
  // custom
  
  ], function (
      declare
  ) {
   
  return declare(null, {
    constructor: function () {
     
      // reference to self
      var x = this;
      


      
    }
  });
});






/************  Application  **********/
(function() {
	require({
		parseOnLoad: true
	});

	dojo.require("esri.dijit.editing.Editor-all");

	require([
		"esri/arcgis/utils",
		"esri/map",
		"esri/Color",
		"esri/config",
		"esri/dijit/Basemap",
		"esri/dijit/BasemapGallery",
		"esri/dijit/BasemapLayer",
		"esri/dijit/Print",
		"esri/dijit/editing/AttachmentEditor",
		"esri/dijit/editing/Editor",
		"esri/dijit/Geocoder",

		"esri/geometry/webMercatorUtils",
		"esri/graphic",
		"esri/InfoTemplate",

		"esri/tasks/GeometryService",
		"esri/tasks/PrintParameters",
		"esri/tasks/PrintTask",
		"esri/tasks/PrintTemplate",
		"esri/tasks/query",
		"esri/tasks/QueryTask",
		"esri/TimeExtent", 
		"esri/dijit/TimeSlider",
		"esri/units",
		
		"dojo/_base/array",
		"dojo/_base/connect",
		"dojo/dom",
		"dojo/dom-construct",
		"dojo/i18n!esri/nls/jsapi",
		"dojo/keys",
		"dojo/on",
		"dojo/query",
		"dojo/parser",
    
    // custom
    "managers/appManager",
    "managers/mapClickManager",
    "regions/bannerRegion",
    "widgets/layersWidget",
    "widgets/locatorWidget",
		
		// Arguments not included in callback
		"dijit/layout/BorderContainer",
		"dijit/layout/ContentPane",
		"dijit/form/TextBox",
		"dijit/TitlePane",
		"dojo/domReady!"
		
		], function(
				arcgisUtils, Map, Color, esriConfig, Basemap, BasemapGallery, BasemapLayer, Print, AttachmentEditor, Editor, Geocoder, webMercatorUtils, Graphic, InfoTemplate,
        GeometryService, PrintParameters, PrintTask, PrintTemplate, Query, QueryTask, 
        TimeExtent, TimeSlider, Units, arrayUtils, connect, dom, domConstruct, i18n, keys, on, query, parser,
        // custom
        AppManager, MapClickManager, BannerRegion, LayersWidget, LocatorWidget
        //buttonClickHandler, mapClickHandler, templateManager, attachmentWidget, bannerWidget, layerManagerWidget, messagesWidget, panelWidget, LocationUtils, Utilities
				) {
        
        // Parse HS config
        var layersConfig = hsconfig.layersConfig;
        var appDesignConfig = hsconfig.appDesign;
        
        /********** Initialize **********/
        
        // this could be placed in a config file
        var config = {};
        
        // set the web page title
        $("#" + "appConfig-webPageTitle").html(appDesignConfig.webPageTitle);
        
        // add a regions config
        config.regions = {
          bannerRegion: {
            id: "banner",
            config: {
              title: appDesignConfig.applicationTitle,
              subtitle: appDesignConfig.applicationSubtitle,
              icon: "images/icons/globe-24.png"
            }
          },
          panelRegion: {
            id: "panel",
            config: {
              
            }
          }
        };
        
        // create an application manager
        var appManager = new AppManager(config);
       
        /********** Map **********/
         
        // Create the map
        appManager.map = new Map("map", {
          center: [-88.958406, 37.740694],
          zoom: 16,
          basemap: "satellite"
        });
        
        /********** Layers **********/
        
        // add a layers config
        config.layers = hsconfig.layersConfig;
        
        if (config.layers) {
          appManager.layersWidget = new LayersWidget(appManager, config.layers);
          // load the layers
          appManager.layersWidget.load();
        }
        
        /********** Locator **********/
        
        // add a locator config
        config.locator = {
          // enable geocoding
          geocoding: {
            addressLocatorUrl: "http://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer",
            buttonIcon: "images/icons/address-search-24.png"
          },
          // enable geolocation
          geolocation: {
            buttonIcon: "images/icons/geolocate-24.png",
            buttonDomId: "geolocationButtonAbsolute", // if this line is used, the button will be hooked to an existing element, based on the logic in the locatorWidget
            graphicsLayer: "locate_graphics_layer"
          }
        };
        
        // create a locator
        if (config.locator) {
          // add location utils to the app manager
          appManager.locatorWidget = new LocatorWidget(appManager, config.locator);
        }
        
        
        /********** Handle Map Clicks **********/
        appManager.mapClickManager = new MapClickManager(appManager);
        appManager.mapClickManager.init();

    });
    

    
}).call(this);